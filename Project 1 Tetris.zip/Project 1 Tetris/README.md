# Tetris Game

A modern implementation of the classic Tetris game using Python and Pygame.

## Features
- Classic Tetris gameplay
- Modern visual effects and animations
- Background music and sound effects
- Pause menu system
- Game over screen with score display
- Keyboard and mouse controls

## Controls
- Left/Right Arrow: Move piece
- Up Arrow: Rotate piece
- Down Arrow: Soft drop
- Space: Hard drop
- P: Pause game
- ESC: Quit to menu

## Installation
1. Make sure you have Python 3.x installed
2. Install the required dependencies:
   ```
   pip install pygame
   ```
3. Run the game:
   ```
   python tetris.py
   ```

## Building from Source
To create an executable:
1. Install PyInstaller:
   ```
   pip install pyinstaller
   ```
2. Build the executable:
   ```
   pyinstaller --onefile --windowed --add-data "assets/*;assets/" tetris.py
   ```
3. The executable will be created in the `dist` directory

## Credits
- Music: "Tetris BGM" by kontinuum
- Sound Effects: Created by Juhani Junkala and 3DPyramid
- Game Development: [Your Name]

## License
This project is licensed under the MIT License - see the LICENSE file for details