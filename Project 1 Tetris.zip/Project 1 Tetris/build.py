import os
import subprocess
import sys

def build_game():
    print("Starting build process...")
    
    # Create distribution using direct command
    print("Creating executable...")
    pyinstaller_command = [
        sys.executable,
        '-m',
        'pyinstaller',
        '--onefile',
        '--noconsole',
        '--clean',
        '--name', 'Tetris',
        '--add-data', 'assets;assets',
        '--hidden-import', 'pygame',
        'tetris.py'
    ]
    
    try:
        subprocess.run(pyinstaller_command, check=True)
        print("Build complete! Check the 'dist' folder for the executable.")
    except subprocess.CalledProcessError as e:
        print(f"Build failed with error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    build_game()