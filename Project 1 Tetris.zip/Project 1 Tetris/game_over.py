import pygame
from game_state import GameState

class GameOverScreen:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        try:
            self.title_font = pygame.font.SysFont('Arial Black', 74, bold=True)
            self.button_font = pygame.font.SysFont('Arial', 36, bold=True)
        except:
            self.title_font = pygame.font.Font(None, 74)
            self.button_font = pygame.font.Font(None, 36)
            
        # Initialize buttons dictionary
        self.buttons = {
            'restart': {'selected': True},
            'quit': {'selected': False}
        }
        
        self.blink_timer = 0
        self.blink_speed = 400
        self.show_button = True
        self.selected_option = 0
        
        # Initialize button rectangles with default positions
        continue_text = "Restart"
        quit_text = "Quit"
        
        x = width//2 - self.button_font.size(continue_text)[0]//2
        y = height//2 + 100
        self.continue_button = pygame.Rect(x-20, y-10,
                                         self.button_font.size(continue_text)[0]+40,
                                         self.button_font.size(continue_text)[1]+20)
        
        x = width//2 - self.button_font.size(quit_text)[0]//2
        y = height//2 + 200
        self.quit_button = pygame.Rect(x-20, y-10,
                                     self.button_font.size(quit_text)[0]+40,
                                     self.button_font.size(quit_text)[1]+20)
        
        self.continue_color = (240, 160, 0)
        self.quit_color = (255, 0, 0)
        
        # Sound
        self.game_over_played = False
        self.game_over_channel = pygame.mixer.Channel(0)
        self.game_over_channel.set_volume(1.0)

    def draw_3d_text(self, screen, text, font, color, x, y, depth=3):
        # Draw shadow layers
        for i in range(depth):
            shadow = font.render(text, True, (color[0]//3, color[1]//3, color[2]//3))
            screen.blit(shadow, (x + i*2, y + i*2))
        
        # Draw main text with shadow
        text_surface = font.render(text, True, color)
        shadow_surface = font.render(text, True, (20, 20, 20))
        
        # Draw shadow slightly offset
        screen.blit(shadow_surface, (x + 2, y + 2))
        # Draw main text
        screen.blit(text_surface, (x, y))

    def draw(self, screen, score, game):
        # Draw the game screen in background
        if hasattr(self, 'game_surface'):
            screen.blit(self.game_surface, (0, 0))
        else:
            screen.fill((0, 0, 0))
            
        # Create semi-transparent overlay
        overlay = pygame.Surface((self.width, self.height))
        overlay.fill((0, 0, 0))
        overlay.set_alpha(160)
        screen.blit(overlay, (0, 0))

        # Draw GAME OVER title
        title_text = "GAME OVER"
        text_width = self.title_font.size(title_text)[0]
        x = self.width//2 - text_width//2
        y = self.height//4
        self.draw_3d_text(screen, title_text, self.title_font, (255, 0, 0), x, y, 4)

        # Draw score
        score_text = f"Final Score: {score}"
        x = self.width//2 - self.button_font.size(score_text)[0]//2
        y = self.height//4 + 100
        self.draw_3d_text(screen, score_text, self.button_font, (255, 255, 255), x, y, 3)

        # Update blink state
        current_time = pygame.time.get_ticks()
        if current_time - self.blink_timer > self.blink_speed:
            self.show_button = not self.show_button
            self.blink_timer = current_time

        mouse_pos = pygame.mouse.get_pos()

        # Draw buttons with same style as pause menu
        restart_text = "Restart"
        x = self.width//2 - self.button_font.size(restart_text)[0]//2
        y = self.height//2 + 100
        if self.continue_button.collidepoint(mouse_pos):
            if self.show_button:
                self.draw_3d_text(screen, restart_text, self.button_font, self.continue_color, x, y, 3)
        elif self.quit_button.collidepoint(mouse_pos):
            self.draw_3d_text(screen, restart_text, self.button_font, self.continue_color, x, y, 3)
        elif self.selected_option == 0:
            if self.show_button:
                self.draw_3d_text(screen, restart_text, self.button_font, self.continue_color, x, y, 3)
        else:
            self.draw_3d_text(screen, restart_text, self.button_font, self.continue_color, x, y, 3)

        # Draw quit button
        quit_text = "Quit"
        x = self.width//2 - self.button_font.size(quit_text)[0]//2
        y = self.height//2 + 200
        if self.quit_button.collidepoint(mouse_pos):
            if self.show_button:
                self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        elif self.continue_button.collidepoint(mouse_pos):
            self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        elif self.selected_option == 1:
            if self.show_button:
                self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        else:
            self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)

        # Play game over sound
        if not self.game_over_played:
            pygame.mixer.music.stop()
            self.game_over_channel.play(game.sounds['game_over'], loops=-1)
            self.game_over_played = True

    def handle_input(self, game):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return GameState.QUIT

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_DOWN):
                    game.play_sound('menu_move')
                    self.selected_option = 1 - self.selected_option
                elif event.key == pygame.K_RETURN:
                    self.game_over_channel.stop()
                    if self.selected_option == 0:
                        game.play_sound('start')
                        return GameState.GAME
                    else:
                        game.play_sound('quit')
                        return GameState.MENU

        return GameState.GAME_OVER