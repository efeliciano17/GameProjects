from tetris.src.game_state import GameState

class GameStateManager:
    def __init__(self):
        self.current_state = GameState.MENU
        
    def change_state(self, new_state):
        self.current_state = new_state
        
    def get_state(self):
        return self.current_state 