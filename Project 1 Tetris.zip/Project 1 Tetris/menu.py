import pygame
import random
import math
from game_state import GameState
from particle_system import ParticleSystem

class Menu:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        
        # Initialize fonts
        try:
            self.title_font = pygame.font.SysFont('Arial Black', 100, bold=True)
            self.button_font = pygame.font.SysFont('Arial', 36, bold=True)
        except:
            self.title_font = pygame.font.Font(None, 100)
            self.button_font = pygame.font.Font(None, 36)

        # Bright colorful palette
        self.block_colors = [
            (0, 255, 255),     # Bright Cyan
            (255, 255, 0),     # Bright Yellow
            (255, 50, 255),    # Bright Magenta
            (50, 255, 50),     # Bright Green
            (255, 50, 50),     # Bright Red
            (50, 150, 255),    # Bright Blue
            (255, 180, 0)      # Bright Orange
        ]
        
        # Start button color
        self.start_color = (255, 255, 0)  # Yellow

        # Setup button
        self.setup_button()

        # Background blocks setup
        self.block_size = 30
        self.blocks = []
        for x in range(-self.block_size, width + self.block_size, self.block_size):
            for y in range(-self.block_size, height + self.block_size, self.block_size):
                self.blocks.append({
                    'x': x,
                    'y': y,
                    'color': random.choice(self.block_colors),
                    'offset': -(x + y) / 200  # Negative for opposite direction
                })

        # Animation settings
        self.time_passed = 0
        self.blink_timer = 0
        self.blink_speed = 400
        self.show_button = True

        # Add bounce settings for letters
        self.letter_bounces = []
        for _ in range(6):  # One for each letter in "TETRIS"
            self.letter_bounces.append({
                'speed': random.uniform(2, 4),
                'offset': random.uniform(0, math.pi * 2),
                'height': random.uniform(8, 12)
            })

        # Vibrant colors specifically for TETRIS letters
        self.title_colors = [
            (255, 0, 0),      # T - Bright Red
            (255, 165, 0),    # E - Orange
            (255, 255, 0),    # T - Yellow
            (50, 255, 50),    # R - Neon Green
            (0, 191, 255),    # I - Deep Sky Blue
            (255, 0, 255)     # S - Magenta
        ]

        # Tetris pieces definitions
        self.tetris_pieces = {
            'I': [(0,0), (0,1), (0,2), (0,3)],
            'O': [(0,0), (1,0), (0,1), (1,1)],
            'T': [(0,1), (1,0), (1,1), (1,2)],
            'S': [(0,1), (0,2), (1,0), (1,1)],
            'Z': [(0,0), (0,1), (1,1), (1,2)],
            'J': [(0,0), (1,0), (1,1), (1,2)],
            'L': [(0,2), (1,0), (1,1), (1,2)]
        }

        # Background falling pieces
        self.falling_pieces = []
        for _ in range(15):  # Number of pieces in background
            self.falling_pieces.append({
                'piece': random.choice(list(self.tetris_pieces.keys())),
                'x': random.randint(0, width),
                'y': random.randint(-height, height),
                'color': random.choice(self.block_colors),
                'speed': random.uniform(0.5, 2),
                'size': random.randint(20, 30),  # Size of each block in piece
                'alpha': random.randint(30, 80)  # Transparency
            })

        # Setup falling tetris symbols
        self.falling_symbols = []
        self.symbol_size = 25
        columns = width // self.symbol_size
        
        for x in range(columns):
            self.falling_symbols.append({
                'x': x * self.symbol_size,
                'y': random.randint(-height, 0),
                'speed': random.uniform(2, 5),
                'color': random.choice(self.block_colors),
                'shape': random.choice(['■', '□', '▣', '▤', '▥', '▦']),
                'alpha': random.randint(40, 180),
                'trail_length': random.randint(4, 8)
            })

        # Initialize particle system
        self.particle_system = ParticleSystem(width, height, self.block_colors)

        # Add background dots setup
        self.dots = []
        for _ in range(50):  # Create 50 sparse dots
            self.dots.append({
                'x': random.randint(0, width),
                'y': random.randint(0, height),
                'size': random.randint(1, 3),
                'color': random.choice(self.block_colors),
                'glow_speed': random.uniform(1, 2)
            })

    def setup_button(self):
        start_text = "START"
        x = self.width//2 - self.button_font.size(start_text)[0]//2
        y = self.height//2 + 150
        self.start_button = pygame.Rect(
            x-20, y-10,
            self.button_font.size(start_text)[0]+40,
            self.button_font.size(start_text)[1]+20
        )

    def draw_3d_text(self, screen, text, font, color, x, y, depth=3):
        # Draw shadow layers
        for i in range(depth):
            shadow = font.render(text, True, (color[0]//3, color[1]//3, color[2]//3))
            screen.blit(shadow, (x + i*2, y + i*2))
        
        # Draw main text
        text_surface = font.render(text, True, color)
        screen.blit(text_surface, (x, y))

    def draw_colorful_block(self, screen, x, y, color, alpha):
        # Create block surface
        base_surf = pygame.Surface((self.block_size, self.block_size), pygame.SRCALPHA)
        
        # Draw main block with base color
        base_color = tuple(int(c * 0.3) for c in color[:3])  # Slightly darker base
        pygame.draw.rect(base_surf, (*base_color, alpha), 
                        (0, 0, self.block_size, self.block_size))
        
        # Draw edge with fixed glow
        edge_color = tuple(min(255, int(c * 1.2)) for c in color[:3])  # Bright edge
        pygame.draw.rect(base_surf, (*edge_color, alpha), 
                        (0, 0, self.block_size, self.block_size), 2)
        
        # Draw block at exact position
        screen.blit(base_surf, (x, y))

    def draw_3d_text_with_glow(self, screen, text, font, color, x, y, depth=3):
        # Draw outer glow
        glow_color = tuple(min(255, c + 150) for c in color[:3])
        for i in range(6):  # More glow layers
            glow = font.render(text, True, glow_color)
            alpha = 50 - i * 8  # Fade out glow
            glow.set_alpha(alpha)
            screen.blit(glow, (x - i, y - i))
            screen.blit(glow, (x + i, y - i))
            screen.blit(glow, (x - i, y + i))
            screen.blit(glow, (x + i, y + i))
        
        # Draw 3D shadow effect
        for i in range(depth):
            shadow = font.render(text, True, (color[0]//3, color[1]//3, color[2]//3))
            screen.blit(shadow, (x + i*2, y + i*2))
        
        # Draw main text
        text_surface = font.render(text, True, color)
        screen.blit(text_surface, (x, y))

    def draw_modern_grid(self, screen):
        # Draw dark base
        screen.fill((0, 0, 40))
        
        # Grid parameters
        cell_size = 80  # Size of each grid cell
        padding = 2    # Space between cells
        alpha = 25     # Transparency of cells
        
        # Draw grid of color squares
        for x in range(0, self.width + cell_size, cell_size):
            for y in range(0, self.height + cell_size, cell_size):
                # Create surface for cell
                cell_surf = pygame.Surface((cell_size - padding, cell_size - padding), pygame.SRCALPHA)
                
                # Pick color from palette
                base_color = random.choice(self.block_colors)
                
                # Draw cell with transparency
                pygame.draw.rect(cell_surf, (*base_color, alpha), 
                               (0, 0, cell_size - padding, cell_size - padding))
                
                # Add subtle gradient
                gradient_surf = pygame.Surface((cell_size - padding, cell_size - padding), pygame.SRCALPHA)
                gradient_alpha = 10
                pygame.draw.rect(gradient_surf, (255, 255, 255, gradient_alpha), 
                               (0, 0, cell_size - padding, cell_size//2))
                cell_surf.blit(gradient_surf, (0, 0))
                
                # Draw to screen
                screen.blit(cell_surf, (x, y))

    def draw_tetris_piece(self, screen, piece_data):
        piece_shape = self.tetris_pieces[piece_data['piece']]
        size = piece_data['size']
        
        # Create surface for piece
        max_size = size * 4  # Maximum possible size needed
        piece_surf = pygame.Surface((max_size, max_size), pygame.SRCALPHA)
        
        # Draw each block of the piece
        for block in piece_shape:
            x, y = block
            block_surf = pygame.Surface((size-1, size-1), pygame.SRCALPHA)
            
            # Draw block with subtle gradient
            base_color = tuple(int(c * 0.7) for c in piece_data['color'])
            pygame.draw.rect(block_surf, (*base_color, piece_data['alpha']), 
                           (0, 0, size-1, size-1))
            
            # Add highlight
            highlight_color = piece_data['color']
            pygame.draw.rect(block_surf, (*highlight_color, piece_data['alpha']), 
                           (0, 0, size-1, size-1), 2)
            
            piece_surf.blit(block_surf, (x * size, y * size))
        
        screen.blit(piece_surf, (piece_data['x'], piece_data['y']))

    def draw_background_grid(self, screen):
        # Draw dark background
        screen.fill((0, 0, 40))
        
        # Draw grid lines
        grid_size = 30
        grid_alpha = 20
        
        for x in range(0, self.width, grid_size):
            pygame.draw.line(screen, (255, 255, 255, grid_alpha), 
                           (x, 0), (x, self.height))
        for y in range(0, self.height, grid_size):
            pygame.draw.line(screen, (255, 255, 255, grid_alpha), 
                           (0, y), (self.width, y))

    def draw_background(self, screen):
        # Draw dark base with subtle gradient
        for y in range(self.height):
            progress = y / self.height
            color = (
                int(0 + progress * 10),
                int(0 + progress * 10),
                int(20 + progress * 30)
            )
            pygame.draw.line(screen, color, (0, y), (self.width, y))

        # Draw falling symbols with trails
        for symbol in self.falling_symbols:
            # Draw trailing symbols with fade
            for i in range(symbol['trail_length']):
                trail_y = symbol['y'] - (i * self.symbol_size)
                if 0 <= trail_y <= self.height:
                    alpha = symbol['alpha'] * (1 - i/symbol['trail_length'])
                    color = symbol['color']
                    
                    # Create fading symbol
                    font = pygame.font.Font(None, self.symbol_size * 2)
                    text = font.render(symbol['shape'], True, color)
                    text.set_alpha(int(alpha))
                    
                    # Add glow effect
                    glow_surf = pygame.Surface((self.symbol_size*2, self.symbol_size*2), pygame.SRCALPHA)
                    glow_color = tuple(min(255, c + 50) for c in color)
                    glow_text = font.render(symbol['shape'], True, glow_color)
                    glow_text.set_alpha(int(alpha * 0.5))
                    
                    # Draw glow and symbol
                    screen.blit(glow_text, (symbol['x']-1, trail_y-1))
                    screen.blit(text, (symbol['x'], trail_y))

            # Update position
            symbol['y'] += symbol['speed']
            if symbol['y'] > self.height:
                symbol['y'] = random.randint(-100, 0)
                symbol['color'] = random.choice(self.block_colors)
                symbol['alpha'] = random.randint(40, 180)
                symbol['shape'] = random.choice(['■', '□', '▣', '▤', '▥', '▦'])

    def draw(self, screen, game):
        self.time_passed = pygame.time.get_ticks() * 0.001
        
        # Draw dark blue gradient background
        for y in range(self.height):
            progress = y / self.height
            color = (
                0,                          # No red
                0,                          # No green
                int(20 + (progress * 40))   # Dark blue gradient from 20 to 60
            )
            pygame.draw.line(screen, color, (0, y), (self.width, y))

        # Draw glowing dots
        for dot in self.dots:
            # Calculate glow intensity
            glow = (math.sin(self.time_passed * dot['glow_speed']) + 1) * 0.5  # 0 to 1
            color = dot['color']
            
            # Draw glow
            glow_size = dot['size'] * 2
            glow_surf = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
            glow_alpha = int(100 * glow)  # Pulsing alpha
            pygame.draw.circle(glow_surf, (*color, glow_alpha), 
                             (glow_size, glow_size), glow_size)
            screen.blit(glow_surf, 
                       (dot['x'] - glow_size, dot['y'] - glow_size))
            
            # Draw main dot
            pygame.draw.circle(screen, color, 
                             (dot['x'], dot['y']), dot['size'])

        # Draw "TETRIS" text with random bouncing
        text = "TETRIS"
        total_width = sum(self.title_font.size(letter)[0] for letter in text)
        base_x = self.width//2 - total_width//2
        base_y = self.height//4

        # Draw each letter with individual random bounce
        letter_x = base_x
        for i, letter in enumerate(text):
            bounce = self.letter_bounces[i]
            bounce_offset = math.sin(self.time_passed * bounce['speed'] + bounce['offset']) * bounce['height']
            y = base_y + bounce_offset
            
            color = self.title_colors[i]
            self.draw_3d_text_with_glow(screen, letter, self.title_font, color, letter_x, y, 4)
            letter_x += self.title_font.size(letter)[0]

        # Draw Start button
        if self.show_button:
            x = self.width//2 - self.button_font.size("START")[0]//2
            y = self.height//2 + 150
            self.draw_3d_text(screen, "START", self.button_font, self.start_color, x, y, 3)

        # Update button blinking
        current_time = pygame.time.get_ticks()
        if current_time - self.blink_timer > self.blink_speed:
            self.show_button = not self.show_button
            self.blink_timer = current_time

    def handle_input(self, game):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return GameState.QUIT

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    mouse_pos = pygame.mouse.get_pos()
                    if self.start_button.collidepoint(mouse_pos):
                        game.play_sound('start')
                        return GameState.GAME

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    game.play_sound('start')
                    return GameState.GAME

        return GameState.MENU