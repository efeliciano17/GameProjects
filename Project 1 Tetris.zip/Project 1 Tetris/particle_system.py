import pygame
import random
import math

class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.randint(3, 8)
        self.speed = random.uniform(0.5, 2)
        self.angle = random.uniform(0, math.pi * 2)
        self.pulse_speed = random.uniform(2, 4)
        self.birth_time = pygame.time.get_ticks() * 0.001
        self.lifetime = random.uniform(2, 5)
        # Initialize alpha
        self.alpha = 255
        self.current_size = self.size

    def update(self, time):
        # Update position with floating motion
        self.x += math.cos(self.angle + time) * self.speed * 0.5
        self.y += math.sin(self.angle + time) * self.speed * 0.5
        
        # Calculate alpha based on lifetime
        age = time - self.birth_time
        self.alpha = max(0, min(255, int(255 * (1 - age/self.lifetime))))
        
        # Pulse size
        self.current_size = self.size * (0.8 + math.sin(time * self.pulse_speed) * 0.2)

    def draw(self, screen):
        if self.alpha <= 0:
            return False

        # Create surface for particle
        surf = pygame.Surface((self.current_size * 2, self.current_size * 2), pygame.SRCALPHA)
        
        # Draw main particle
        pygame.draw.circle(surf, (*self.color, self.alpha), 
                         (self.current_size, self.current_size), 
                         self.current_size)
        
        # Draw glow
        glow_color = tuple(min(255, c + 50) for c in self.color)
        glow_size = self.current_size * 1.5
        pygame.draw.circle(surf, (*glow_color, self.alpha//2),
                         (self.current_size, self.current_size),
                         glow_size)
        
        # Draw to screen
        screen.blit(surf, (self.x - self.current_size, self.y - self.current_size))
        return True

class ParticleSystem:
    def __init__(self, width, height, colors):
        self.width = width
        self.height = height
        # Brighter, more saturated colors for white background
        self.colors = [
            (0, 180, 255),    # Bright Blue
            (255, 50, 50),    # Bright Red
            (50, 205, 50),    # Bright Green
            (255, 140, 0),    # Bright Orange
            (138, 43, 226),   # Purple
            (255, 20, 147)    # Pink
        ]
        self.particles = []
        
        # Initial particle creation
        self.create_particles(50)

    def create_particles(self, count):
        for _ in range(count):
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            color = random.choice(self.colors)
            self.particles.append(Particle(x, y, color))

    def update_and_draw(self, screen, time):
        # Remove dead particles
        self.particles = [p for p in self.particles if p.alpha > 0]
        
        # Create new particles as needed
        if len(self.particles) < 50:
            self.create_particles(5)
        
        # Update and draw all particles
        for particle in self.particles:
            particle.update(time)
            particle.draw(screen)
            
            # Wrap particles around screen
            if particle.x < 0: particle.x = self.width
            if particle.x > self.width: particle.x = 0
            if particle.y < 0: particle.y = self.height
            if particle.y > self.height: particle.y = 0