import pygame
from game_state import GameState

class PauseMenu:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        try:
            self.title_font = pygame.font.SysFont('Arial Black', 74, bold=True)
            self.button_font = pygame.font.SysFont('Arial', 36, bold=True)
        except:
            self.title_font = pygame.font.Font(None, 74)
            self.button_font = pygame.font.Font(None, 36)
            
        self.blink_timer = 0
        self.blink_speed = 400
        self.show_button = True
        self.pause_initialized = False
        
        # Initialize button rectangles with default positions
        continue_text = "Continue"
        quit_text = "Quit"
        
        x = width//2 - self.button_font.size(continue_text)[0]//2
        y = height//2 + 50
        self.continue_button = pygame.Rect(x-20, y-10,
                                         self.button_font.size(continue_text)[0]+40,
                                         self.button_font.size(continue_text)[1]+20)
        
        x = width//2 - self.button_font.size(quit_text)[0]//2
        y = height//2 + 200
        self.quit_button = pygame.Rect(x-20, y-10,
                                     self.button_font.size(quit_text)[0]+40,
                                     self.button_font.size(quit_text)[1]+20)
        
        self.continue_color = (240, 160, 0)
        self.quit_color = (255, 0, 0)
        self.selected_option = 0

    def draw_3d_text(self, screen, text, font, color, x, y, depth=3):
        # Draw shadow layers
        for i in range(depth):
            shadow = font.render(text, True, (color[0]//3, color[1]//3, color[2]//3))
            screen.blit(shadow, (x + i*2, y + i*2))
        
        # Draw main text with shadow
        text_surface = font.render(text, True, color)
        shadow_surface = font.render(text, True, (20, 20, 20))
        
        # Draw shadow slightly offset
        screen.blit(shadow_surface, (x + 2, y + 2))
        # Draw main text
        screen.blit(text_surface, (x, y))

    def run(self, screen, game_surface, game):
        if not self.pause_initialized:
            pygame.mixer.music.pause()
            game.play_sound('pause_in')
            self.pause_initialized = True
        
        current_time = pygame.time.get_ticks()
        
        # Draw the paused game in background
        screen.blit(game_surface, (0, 0))
        
        # Create semi-transparent overlay
        overlay = pygame.Surface((self.width, self.height))
        overlay.fill((0, 0, 0))
        overlay.set_alpha(160)
        screen.blit(overlay, (0, 0))
        
        # Draw PAUSE title (no blinking)
        pause_text = "PAUSE"
        text_width = self.title_font.size(pause_text)[0]
        x = self.width//2 - text_width//2
        y = self.height//4
        self.draw_3d_text(screen, pause_text, self.title_font, (255, 255, 255), x, y, 4)

        # Update blink state for buttons
        if current_time - self.blink_timer > self.blink_speed:
            self.show_button = not self.show_button
            self.blink_timer = current_time

        mouse_pos = pygame.mouse.get_pos()
        
        # Continue button - moved lower
        continue_text = "Continue"
        x = self.width//2 - self.button_font.size(continue_text)[0]//2
        y = self.height//2 + 50  # Moved 50 pixels lower from center
        self.continue_button = pygame.Rect(x-20, y-10,
                                         self.button_font.size(continue_text)[0]+40,
                                         self.button_font.size(continue_text)[1]+20)
        
        # Draw continue button with blinking effect when selected or hovered
        if self.continue_button.collidepoint(mouse_pos):
            # If hovering over continue, only continue button blinks
            if self.show_button:
                self.draw_3d_text(screen, continue_text, self.button_font, self.continue_color, x, y, 3)
        elif self.quit_button.collidepoint(mouse_pos):
            # If hovering over quit, continue button doesn't blink
            self.draw_3d_text(screen, continue_text, self.button_font, self.continue_color, x, y, 3)
        elif self.selected_option == 0:
            # If continue is selected and not hovering over any button
            if self.show_button:
                self.draw_3d_text(screen, continue_text, self.button_font, self.continue_color, x, y, 3)
        else:
            self.draw_3d_text(screen, continue_text, self.button_font, self.continue_color, x, y, 3)
        
        # Quit button
        quit_text = "Quit"
        x = self.width//2 - self.button_font.size(quit_text)[0]//2
        y = self.height//2 + 200
        self.quit_button = pygame.Rect(x-20, y-10,
                                     self.button_font.size(quit_text)[0]+40,
                                     self.button_font.size(quit_text)[1]+20)
        
        # Draw quit button with blinking effect when selected or hovered
        if self.quit_button.collidepoint(mouse_pos):
            # If hovering over quit, only quit button blinks
            if self.show_button:
                self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        elif self.continue_button.collidepoint(mouse_pos):
            # If hovering over continue, quit button doesn't blink
            self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        elif self.selected_option == 1:
            # If quit is selected and not hovering over any button
            if self.show_button:
                self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)
        else:
            self.draw_3d_text(screen, quit_text, self.button_font, self.quit_color, x, y, 3)

        # Handle input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return GameState.QUIT
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if self.continue_button.collidepoint(mouse_pos):
                        self.pause_initialized = False
                        game.play_sound('pause_out')
                        return GameState.GAME
                    if self.quit_button.collidepoint(mouse_pos):
                        self.pause_initialized = False
                        game.play_sound('start')
                        return GameState.MENU
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    game.play_sound('rotate')
                    self.selected_option = 0
                elif event.key == pygame.K_DOWN:
                    game.play_sound('rotate')
                    self.selected_option = 1
                elif event.key == pygame.K_RETURN:
                    if self.selected_option == 0:
                        game.play_sound('pause_out')
                        return GameState.GAME
                    else:
                        game.play_sound('start')
                        return GameState.MENU
                    
        return GameState.PAUSE