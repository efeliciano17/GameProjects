"""
Tetris Game

Music Credits:
- "Tetris BGM"
  Created by kontinuum
  License: Free for commercial and non-commercial use
  Source: https://kontinuum.itch.io/free-synthwave-music

Sound Effects Credits:
- Sound effects (rotate.wav, drop.wav, clear.wav, pause_in.wav, pause_out.wav, start.wav)
  Created by Juhani Junkala (juhani.junkala@musician.org)
  License: CC0 (Creative Commons Zero)
  These sound effects are part of the "512 Sound Effects (8-bit style)" package
  Portfolio: https://www.youtube.com/watch?v=dbACpSy9FWY
  
  The CC0 license means these sound effects are released into the public domain and can be used
  freely without attribution, but we credit the creator as a courtesy and to support their work.

- game_over.wav
  Created by 3DPyramid
  Portfolio: https://www.instagram.com/3d_pyramid/
  Source: https://opengameart.org/
"""

import pygame
import sys
import traceback
import math
import random
from game_state import GameState
from tetris_game import TetrisGame
from pause_menu import PauseMenu
from menu import Menu
from game_over import GameOverScreen

def main():
    pygame.init()
    pygame.mixer.init()
    
    width = 800
    height = 600
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Tetris")
    
    # Initialize game objects
    menu = Menu(width, height)
    start_screen = Menu(width, height)
    game = TetrisGame(width, height)
    pause_menu = PauseMenu(width, height)
    
    # Game loop
    clock = pygame.time.Clock()
    state = GameState.MENU
    previous_state = None
    
    while True:
        try:
            previous_state = state
            
            if state == GameState.MENU:
                # Make sure music is playing at full volume in menu
                if not pygame.mixer.music.get_busy():
                    pygame.mixer.music.load('assets/music/tetris_bgm.ogg')
                    pygame.mixer.music.set_volume(1.0)
                    pygame.mixer.music.play(-1)
                start_screen.draw(screen, game)
                state = start_screen.handle_input(game)
                if state == GameState.GAME:
                    # Lower volume during gameplay
                    pygame.mixer.music.set_volume(0.2)
            
            elif state == GameState.GAME:
                state = game.run(screen)
                if state == GameState.GAME_OVER:
                    # Store the last game screen before creating game over screen
                    game_over_screen = GameOverScreen(width, height)
                    game_over_screen.game_surface = screen.copy()  # Store the last game screen
                    state = GameState.GAME_OVER
            
            elif state == GameState.GAME_OVER:
                game_over_screen.draw(screen, game.score, game)
                state = game_over_screen.handle_input(game)
                if state == GameState.GAME:
                    # Reset game and music for new game
                    game = TetrisGame(width, height)
                    pygame.mixer.music.set_volume(0.2)
                    pygame.mixer.music.play(-1)
                elif state == GameState.MENU:
                    # Reset game and music for menu
                    game = TetrisGame(width, height)
                    pygame.mixer.music.set_volume(1.0)
                    pygame.mixer.music.play(-1)
            
            elif state == GameState.PAUSE:
                new_state = pause_menu.run(screen, game.pause_surface, game)
                if new_state != GameState.PAUSE:  # If leaving pause state
                    if new_state == GameState.GAME:
                        # Resume music when returning to game
                        pygame.mixer.music.unpause()
                        pygame.mixer.music.set_volume(0.2)
                        game.play_sound('pause_out')
                    elif new_state == GameState.MENU:
                        # Reset game and music when going to menu
                        game = TetrisGame(width, height)
                        pygame.mixer.music.set_volume(1.0)
                        pygame.mixer.music.play(-1)
                state = new_state
            
            elif state == GameState.QUIT:
                pygame.quit()
                sys.exit()
            
            pygame.display.flip()
            clock.tick(60)
            
        except Exception as e:
            print(f"Error: {e}")
            traceback.print_exc()
            pygame.quit()
            sys.exit()

if __name__ == "__main__":
    main() 