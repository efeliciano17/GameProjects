import pygame
import random
from game_state import GameState

class TetrisGame:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.block_size = 25
        self.grid_width = 14
        # Calculate grid height based on screen height
        self.grid_height = self.height // self.block_size  # This will make blocks stop at screen bottom
        self.grid_x = (width - self.grid_width * self.block_size) // 2
        self.grid_y = 0  # Start from the top of the screen
        
        # Update grid array to match new height
        self.grid = [[0 for _ in range(self.grid_width)] for _ in range(self.grid_height)]
        self.score = 0
        
        # Colors
        self.colors = {
            'I': (0, 240, 240),   # Brighter Cyan
            'O': (240, 240, 0),   # Brighter Yellow
            'T': (160, 0, 240),   # Vibrant Purple
            'S': (0, 240, 0),     # Brighter Green
            'Z': (240, 0, 0),     # Brighter Red
            'J': (0, 0, 240),     # Brighter Blue
            'L': (240, 160, 0)    # Brighter Orange
        }
        
        # Colors for controls text
        self.control_colors = [
            (0, 255, 255),   # Cyan
            (255, 0, 0),     # Red
            (0, 255, 0),     # Green
            (255, 255, 0),   # Yellow
            (255, 0, 255),   # Magenta
            (0, 0, 255)      # Blue
        ]
        
        # Tetromino shapes
        self.shapes = {
            'I': [[1, 1, 1, 1]],
            'O': [[1, 1], [1, 1]],
            'T': [[0, 1, 0], [1, 1, 1]],
            'S': [[0, 1, 1], [1, 1, 0]],
            'Z': [[1, 1, 0], [0, 1, 1]],
            'J': [[1, 0, 0], [1, 1, 1]],
            'L': [[0, 0, 1], [1, 1, 1]]
        }
        
        self.current_piece = self.new_piece()
        self.fall_time = 0
        self.fall_speed = 500  # milliseconds
        self.last_fall = pygame.time.get_ticks()
        
        # Next piece
        self.next_piece = self.new_piece()
        
        # Try to load bold font with different sizes
        try:
            self.control_title_font = pygame.font.SysFont('Arial Black', 20, bold=True)  # Smaller CONTROLS
            self.control_font = pygame.font.SysFont('Arial', 16, bold=True)  # Smaller control instructions
        except:
            self.control_title_font = pygame.font.Font(None, 20)
            self.control_font = pygame.font.Font(None, 16)
        
        self.paused = False
        self.pause_surface = None  # To store the game screen when paused
        
        # Add block style
        self.block_inner_size = self.block_size - 4  # Smaller inner block for 3D effect
        
        # Initialize mixer if not already initialized
        if not pygame.mixer.get_init():
            pygame.mixer.init()
            
        # Load sounds
        self.sounds = {}
        sound_files = {
            'drop': 'drop.wav',
            'rotate': 'rotate.wav',
            'clear': 'clear.wav',
            'start': 'start.wav',
            'game_over': 'game_over.wav',
            'pause_in': 'pause_in.wav',
            'pause_out': 'pause_out.wav',
            'menu_move': 'start.wav',
            'quit': 'start.wav'
        }

        for sound_name, file_name in sound_files.items():
            try:
                path = f'assets/sounds/{file_name}'
                self.sounds[sound_name] = pygame.mixer.Sound(path)
            except:
                print(f"Error loading sound {sound_name}: No file '{path}' found")
                # Create a silent sound as fallback
                self.sounds[sound_name] = pygame.mixer.Sound(buffer=b'\x00' * 44100)

    def rotate_piece(self):
        # Get the current piece's shape matrix
        shape = self.current_piece['shape']
        # Transpose and reverse rows to rotate 90 degrees clockwise
        rotated = list(zip(*shape[::-1]))
        
        # Check if rotation is valid
        if self.valid_move({'shape': rotated, 'x': self.current_piece['x'], 'y': self.current_piece['y']},
                          self.current_piece['x'], self.current_piece['y']):
            self.current_piece['shape'] = rotated

    def merge_piece(self):
        for i, row in enumerate(self.current_piece['shape']):
            for j, cell in enumerate(row):
                if cell:
                    y = self.current_piece['y'] + i
                    x = self.current_piece['x'] + j
                    # Only merge if within grid bounds
                    if 0 <= y < self.grid_height:
                        self.grid[y][x] = self.current_piece['color']

    def clear_lines(self):
        lines_cleared = 0
        y = self.grid_height - 1
        while y >= 0:
            if all(cell != 0 for cell in self.grid[y]):
                lines_cleared += 1
                # Move all lines above down
                for y2 in range(y, 0, -1):
                    self.grid[y2] = self.grid[y2-1][:]
                # Clear top line
                self.grid[0] = [0] * self.grid_width
            else:
                y -= 1
                
        # Update score
        if lines_cleared > 0:
            self.play_sound('clear')
            self.score += lines_cleared * 100
            
    def new_piece(self):
        shape_name = random.choice(list(self.shapes.keys()))
        return {
            'shape': self.shapes[shape_name],
            'color': self.colors[shape_name],
            'x': self.grid_width // 2 - len(self.shapes[shape_name][0]) // 2,
            'y': 0
        }
        
    def valid_move(self, piece, x, y):
        for i, row in enumerate(piece['shape']):
            for j, cell in enumerate(row):
                if cell:
                    new_x = x + j
                    new_y = y + i
                    # Add check for bottom boundary
                    if (new_x < 0 or new_x >= self.grid_width or
                        new_y >= self.grid_height or  # Add this line to check bottom boundary
                        (new_y >= 0 and new_y < self.grid_height and self.grid[new_y][new_x])):
                        return False
        return True
        
    def run(self, screen):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return GameState.QUIT
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Enter key for pause
                    self.play_sound('pause_in')  # Add pause_in sound here
                    self.pause_surface = screen.copy()
                    self.stop_music()
                    return GameState.PAUSE
                elif event.key == pygame.K_LEFT:
                    if self.valid_move(self.current_piece, 
                                     self.current_piece['x'] - 1, 
                                     self.current_piece['y']):
                        self.current_piece['x'] -= 1
                elif event.key == pygame.K_RIGHT:
                    if self.valid_move(self.current_piece, 
                                     self.current_piece['x'] + 1, 
                                     self.current_piece['y']):
                        self.current_piece['x'] += 1
                elif event.key == pygame.K_DOWN:
                    if self.valid_move(self.current_piece, 
                                     self.current_piece['x'], 
                                     self.current_piece['y'] + 1):
                        self.current_piece['y'] += 1
                elif event.key == pygame.K_UP:
                    self.rotate_piece()
                    self.play_sound('rotate')
                elif event.key == pygame.K_SPACE:
                    self.play_sound('drop')
                    if self.hard_drop():
                        return GameState.GAME_OVER
                elif event.key == pygame.K_m:  # M key to mute/unmute
                    self.toggle_music()

        # Handle automatic falling
        current_time = pygame.time.get_ticks()
        if current_time - self.last_fall > self.fall_speed:
            if self.valid_move(self.current_piece, 
                             self.current_piece['x'], 
                             self.current_piece['y'] + 1):
                self.current_piece['y'] += 1
            else:
                self.merge_piece()
                self.clear_lines()
                self.current_piece = self.next_piece
                self.next_piece = self.new_piece()
                if not self.valid_move(self.current_piece, 
                                     self.current_piece['x'], 
                                     self.current_piece['y']):
                    return GameState.GAME_OVER
            self.last_fall = current_time

        self.draw(screen)
        return GameState.GAME
        
    def spawn_new_piece(self):
        self.current_piece = self.next_piece
        self.next_piece = self.new_piece()
        return not self.valid_move(self.current_piece, 
                                 self.current_piece['x'], 
                                 self.current_piece['y'])

    def draw_gradient_background(self, screen):
        gradient_rect = pygame.Surface((self.width, self.height))
        for y in range(self.height):
            # Calculate gradient color
            ratio = y / self.height
            # Dark purple gradient (from darker to lighter)
            color = [
                int(25 + (40 - 25) * ratio),  # R
                int(0 + (0 - 0) * ratio),     # G
                int(51 + (76 - 51) * ratio)   # B
            ]
            pygame.draw.line(gradient_rect, color, (0, y), (self.width, y))
        screen.blit(gradient_rect, (0, 0))

    def draw_slick_text(self, screen, text, font, color, x, y, glow=True):
        """Draw text with a modern, slick appearance"""
        # Base shadow (darker, further offset)
        shadow_color = (20, 20, 20)
        base_shadow = font.render(text, True, shadow_color)
        screen.blit(base_shadow, (x + 3, y + 3))
        
        # Gradient shadow effect
        for i in range(3):
            alpha = 160 - i * 50
            shadow = font.render(text, True, shadow_color)
            shadow_surface = pygame.Surface(shadow.get_size(), pygame.SRCALPHA)
            shadow_surface.fill((0, 0, 0, alpha))
            shadow.blit(shadow_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            screen.blit(shadow, (x + 2 - i, y + 2 - i))
        
        # Main text with subtle gradient
        main_text = font.render(text, True, color)
        
        # Add glow effect if enabled
        if glow:
            # Create glow surface
            glow_surface = pygame.Surface(main_text.get_size(), pygame.SRCALPHA)
            glow_color = tuple(min(255, c + 50) for c in color)  # Lighter version of text color
            glow_text = font.render(text, True, glow_color)
            
            # Apply glow with different alpha values
            for i in range(3):
                alpha = 100 - i * 30
                temp_surface = glow_text.copy()
                temp_surface.set_alpha(alpha)
                screen.blit(temp_surface, (x - i, y - i))
        
        # Draw main text
        screen.blit(main_text, (x, y))

    def draw_next_piece(self, screen):
        # Calculate positions - adjust the y position to move it down
        next_x = self.grid_x + self.grid_width * self.block_size + 50  # Keep same x position
        next_y = self.grid_y + 50  # Add offset to move down (increase this value to move lower)
        
        # Calculate preview box size
        block_size = self.block_size * 0.8  # Slightly smaller blocks for next piece
        piece_width = len(self.next_piece['shape'][0]) * block_size
        piece_height = len(self.next_piece['shape']) * block_size
        
        # Calculate centered position for the piece
        preview_width = max(140, piece_width + 60)   # Wider box
        
        # Calculate total height needed
        text_height = 40  # Space for "NEXT" text
        piece_space = piece_height + 60  # Reduced space for better centering
        score_height = 40  # Space for score text
        preview_height = text_height + piece_space + score_height  # Total height needed
        
        # Draw outer border box (thicker)
        border_rect = pygame.Rect(next_x - 10, next_y, preview_width + 20, preview_height)
        
        # Fill with black background first
        pygame.draw.rect(screen, (0, 0, 0), border_rect)
        
        # Draw "NEXT" text
        font_size = 22
        next_text = "NEXT"
        font = pygame.font.Font(None, font_size)
        text_rect = pygame.Rect(next_x + 20, next_y + 20, 0, 0)
        self.draw_slick_text(screen, next_text, font, (255, 255, 255), text_rect.x, text_rect.y)
        
        # Calculate vertical center position for the piece
        available_height = preview_height - text_height - score_height
        piece_y = next_y + text_height + (available_height - piece_height) // 2
        
        # Center the piece horizontally
        piece_x = next_x + (preview_width - piece_width) // 2

        # Draw next piece with shadow effect
        shadow_offset = 2
        for i, row in enumerate(self.next_piece['shape']):
            for j, cell in enumerate(row):
                if cell:
                    # Draw shadow
                    pygame.draw.rect(screen, (50, 50, 50),
                                   (piece_x + j * block_size + shadow_offset,
                                    piece_y + i * block_size + shadow_offset,
                                    block_size - 1, block_size - 1))
                    # Draw block
                    pygame.draw.rect(screen, self.next_piece['color'],
                                   (piece_x + j * block_size,
                                    piece_y + i * block_size,
                                    block_size - 1, block_size - 1))
                    # Draw block border
                    pygame.draw.rect(screen, (128, 128, 128),
                                   (piece_x + j * block_size,
                                    piece_y + i * block_size,
                                    block_size - 1, block_size - 1), 1)

        # Draw score
        score_str = f"SCORE: {self.score}"
        text_rect = pygame.Rect(next_x + 20, 
                              next_y + preview_height - score_height + 5,
                              0, 0)
        self.draw_slick_text(screen, score_str, font, (255, 255, 255), text_rect.x, text_rect.y)

        # Draw the border around the entire black section last
        pygame.draw.rect(screen, (128, 128, 128), border_rect, 3)

    def draw_controls(self, screen):
        control_x = self.grid_x + self.grid_width * self.block_size + 50
        control_y = self.height - 180
        line_spacing = 20

        # Draw "CONTROLS" title with colors and shadow
        title = "CONTROLS"
        total_width = sum(self.control_title_font.size(letter)[0] for letter in title)
        current_x = control_x
        
        for i, letter in enumerate(title):
            color = self.control_colors[i % len(self.control_colors)]
            self.draw_slick_text(screen, letter, self.control_title_font, color, current_x, control_y, glow=True)
            current_x += self.control_title_font.size(letter)[0]

        # Control instructions with shadow
        controls = [
            ("← → : Move", (0, 255, 255)),     # Cyan - Fixed left arrow
            ("↑ : Rotate", (255, 255, 0)),     # Yellow
            ("↓ : Soft Drop", (255, 0, 255)),  # Magenta
            ("SPACE: Hard Drop", (0, 255, 0)), # Green
            ("ENTER: Pause", (255, 0, 0))      # Red
        ]

        for i, (control, color) in enumerate(controls):
            y_pos = control_y + (i + 1.5) * line_spacing
            self.draw_slick_text(screen, control, self.control_font, color, control_x, y_pos, glow=False)

    def draw_block(self, screen, x, y, color):
        """Draw a single block with 3D effect"""
        # Draw main block
        pygame.draw.rect(screen, color,
                        (x, y, self.block_size - 1, self.block_size - 1))
        
        # Draw lighter top/left edges
        light_color = self.lighten_color(color)
        pygame.draw.line(screen, light_color, (x, y), (x + self.block_size - 2, y), 2)
        pygame.draw.line(screen, light_color, (x, y), (x, y + self.block_size - 2), 2)
        
        # Draw darker bottom/right edges
        dark_color = self.darken_color(color)
        pygame.draw.line(screen, dark_color, 
                        (x + self.block_size - 2, y),
                        (x + self.block_size - 2, y + self.block_size - 2), 2)
        pygame.draw.line(screen, dark_color,
                        (x, y + self.block_size - 2),
                        (x + self.block_size - 2, y + self.block_size - 2), 2)
        
    def lighten_color(self, color):
        """Make a color lighter"""
        return tuple(min(255, c + 50) for c in color)
        
    def darken_color(self, color):
        """Make a color darker"""
        return tuple(max(0, c - 50) for c in color)

    def draw_grid_lines(self, screen):
        """Draw subtle grid lines"""
        grid_color = (30, 30, 30)  # Changed from (50, 50, 50) to darker color
        
        # Draw vertical lines
        for x in range(self.grid_width + 1):
            x_pos = self.grid_x + x * self.block_size
            pygame.draw.line(screen, grid_color,
                           (x_pos, 0),  # Start from top of screen
                           (x_pos, self.height))  # Go to bottom of screen
        
        # Draw horizontal lines
        for y in range(self.height // self.block_size + 1):  # Cover full height
            y_pos = y * self.block_size
            pygame.draw.line(screen, grid_color,
                           (self.grid_x, y_pos),
                           (self.grid_x + self.grid_width * self.block_size, y_pos))

    def draw_side_block_pattern(self, screen):
        block_size = 25  # Size of each block
        side_width = self.grid_x  # Width of the left side area
        
        # Create surface for the side pattern
        side_surface = pygame.Surface((side_width, self.height), pygame.SRCALPHA)
        
        # Draw block pattern with horizontal fade
        for y in range(0, self.height, block_size):
            for x in range(0, side_width, block_size):
                # Calculate fade based on x position
                fade_ratio = x / side_width
                alpha = max(0, int(255 * (1 - fade_ratio)))  # Fade from left to right
                
                # Draw block outline
                rect = pygame.Rect(x, y, block_size-2, block_size-2)
                pygame.draw.rect(side_surface, (160, 0, 240, alpha), rect, 1)  # Purple outline
                
                # Draw subtle block fill
                inner_rect = pygame.Rect(x+1, y+1, block_size-4, block_size-4)
                pygame.draw.rect(side_surface, (120, 0, 180, alpha//2), inner_rect)  # Darker purple fill
        
        # Draw the side pattern
        screen.blit(side_surface, (0, 0))

    def draw_right_side_block_pattern(self, screen):
        block_size = 25  # Size of each block
        grid_right_edge = self.grid_x + self.grid_width * self.block_size
        side_width = self.width - grid_right_edge  # Width of the right side area
        
        # Create surface for the side pattern
        side_surface = pygame.Surface((side_width, self.height), pygame.SRCALPHA)
        
        # Draw block pattern with horizontal fade (right to left)
        for y in range(0, self.height, block_size):
            for x in range(0, side_width, block_size):
                # Calculate fade based on x position (reversed for right side)
                fade_ratio = (side_width - x) / side_width
                alpha = max(0, int(255 * (1 - fade_ratio)))  # Fade from right to left
                
                # Draw block outline
                rect = pygame.Rect(x, y, block_size-2, block_size-2)
                pygame.draw.rect(side_surface, (160, 0, 240, alpha), rect, 1)  # Purple outline
                
                # Draw subtle block fill
                inner_rect = pygame.Rect(x+1, y+1, block_size-4, block_size-4)
                pygame.draw.rect(side_surface, (120, 0, 180, alpha//2), inner_rect)  # Darker purple fill
        
        # Draw the side pattern (positioned on the right side)
        screen.blit(side_surface, (grid_right_edge, 0))

    def draw(self, screen):
        # Draw gradient background
        self.draw_gradient_background(screen)
        
        # Draw side block patterns
        self.draw_side_block_pattern(screen)      # Left side
        self.draw_right_side_block_pattern(screen)  # Right side
        
        # Draw black background for game grid
        pygame.draw.rect(screen, (0, 0, 0), 
                        (self.grid_x - 2, 0,
                         self.grid_width * self.block_size + 4,
                         self.height))
        
        # Draw subtle grid lines
        self.draw_grid_lines(screen)
        
        # Draw grid border - only left and right sides with glow effect
        for i in range(3):  # Multiple lines for glow effect
            alpha = 100 - i * 30  # Decreasing alpha for outer lines
            color = (128, 128, 128, alpha)
            offset = i * 2
            # Left border
            pygame.draw.line(screen, color,
                           (self.grid_x - 2 - offset, 0),
                           (self.grid_x - 2 - offset, self.height),
                           2)
            # Right border
            pygame.draw.line(screen, color,
                           (self.grid_x + self.grid_width * self.block_size + 2 + offset, 0),
                           (self.grid_x + self.grid_width * self.block_size + 2 + offset, self.height),
                           2)
        
        # Draw grid blocks with 3D effect
        for y, row in enumerate(self.grid):
            for x, cell in enumerate(row):
                if cell:
                    self.draw_block(screen,
                                  self.grid_x + x * self.block_size,
                                  self.grid_y + y * self.block_size,
                                  cell)
        
        # Draw current piece with 3D effect
        for i, row in enumerate(self.current_piece['shape']):
            for j, cell in enumerate(row):
                if cell:
                    y_pos = self.grid_y + (self.current_piece['y'] + i) * self.block_size
                    if 0 <= y_pos < self.height:
                        self.draw_block(screen,
                                      self.grid_x + (self.current_piece['x'] + j) * self.block_size,
                                      y_pos,
                                      self.current_piece['color'])
        
        # Draw next piece
        self.draw_next_piece(screen)
        
        # Draw controls
        self.draw_controls(screen)

    def resume_from_pause(self):
        self.last_fall = pygame.time.get_ticks()  # Reset fall timer when resuming

    def hard_drop(self):
        """Instantly drop the piece to the bottom"""
        # Move piece down until it hits something
        while self.valid_move(self.current_piece, 
                            self.current_piece['x'], 
                            self.current_piece['y'] + 1):
            self.current_piece['y'] += 1
        
        # After reaching bottom, merge piece and spawn new one
        self.merge_piece()
        self.clear_lines()
        self.current_piece = self.next_piece
        self.next_piece = self.new_piece()
        
        # Check if new piece can be placed
        if not self.valid_move(self.current_piece, 
                             self.current_piece['x'], 
                             self.current_piece['y']):
            pygame.mixer.music.stop()
            self.play_sound('game_over')
            return True  # Game over
        return False    # Continue game

    def toggle_music(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()

    def stop_music(self):
        pygame.mixer.music.pause()

    def resume_music(self):
        pygame.mixer.music.unpause()

    def play_sound(self, sound_name):
        print(f"\nTrying to play sound: {sound_name}")  # Debug print
        if sound_name in self.sounds:
            try:
                self.sounds[sound_name].play()
                print(f"Successfully played {sound_name}")
            except Exception as e:
                print(f"Error playing {sound_name}: {e}")
        else:
            print(f"Sound {sound_name} not found in self.sounds")